
setwd('~/Desktop/Paper/analyses/simulated/3-5-noise/')

source('../../../scripts/ref_based.R')

import_data('../../../data/simulated/3-5-noise/genotypes.txt', '../../../data/simulated/3-5-noise/phenotypes.txt')
model <- infer_model(1L, n, 1L)
ord <- model$mut_ord

writeLines(as.character(signif(model$e, 4)), 'RBA-effects.txt')
writeLines(as.character(ord), 'RBA-effect-ord.txt')
