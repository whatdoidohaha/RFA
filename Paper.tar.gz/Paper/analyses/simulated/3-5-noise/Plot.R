
# Simulated map
n <- 5L
s <- 3L

# Reference-based effects.
lambda <- as.numeric(readLines('RBA-effects.txt'))
lambda_ord <- as.numeric(readLines('RBA-effect-ord.txt'))

# Reference-free effects.
e <- as.numeric(readLines('RFA-effects.txt'))
e_ord <- as.numeric(readLines('RFA-effect-ord.txt'))

# Plotting.
spacing <- 2
plot(NA, xlim = c(-0.5, n * spacing + 0.5), ylim = c(-10, 10))
points(spacing * e_ord - 0.5, e, pch = 16L, col = rgb(0, 0, 0, 0.2), cex = 1.5)
points(spacing * lambda_ord + 0.5, lambda, pch = 16L, col = rgb(1, 0, 0, 0.2), cex = 1.5)
abline(h = c(-1, 0, 1))
abline(v = spacing * 1L:n - 1)

# Standard deviations.
for(i in 1L:n) {
  
  points(spacing * i - 0.5, mean(e[e_ord == i]), pch = 3L)
  arrows(x0 = spacing * i - 0.5, y0 = mean(e[e_ord == i]) - sd(e[e_ord == i]),
         x1 = spacing * i - 0.5, y1 = mean(e[e_ord == i]) + sd(e[e_ord == i]), angle = 90, code = 3, length = 0.05)
  points(spacing * i + 0.5, mean(lambda[lambda_ord == i]), pch = 3L)
  arrows(x0 = spacing * i + 0.5, y0 = mean(lambda[lambda_ord == i]) - sd(lambda[lambda_ord == i]),
         x1 = spacing * i + 0.5, y1 = mean(lambda[lambda_ord == i]) + sd(lambda[lambda_ord == i]),
         angle = 90, code = 3, length = 0.05)
}
