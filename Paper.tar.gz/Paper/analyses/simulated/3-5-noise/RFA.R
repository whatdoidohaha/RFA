
setwd('~/Desktop/Paper/analyses/simulated/3-5-noise/')

source('../../../scripts/ref_free_complete_data.R')

set_model(list('../../../data/simulated/3-5-noise/genotypes.txt', '../../../data/simulated/3-5-noise/phenotypes.txt'))
transform_to_ensemble_representation()
e <- calculate_effects()
e_ord <- rowSums(genotypes != 0L)

writeLines(as.character(signif(e, 4)), 'RFA-effects.txt')
writeLines(as.character(e_ord), 'RFA-effect-ord.txt')
