
# Robustness of reference-free analysis to missing genotypes.

# Written in R version 4.3.1.
# Requires R packages abind (1.4-5), glmnet (4.1-7), and lbfgs (1.2.1.2).


# Settings (recommended not to change in a run) ---------------------------

# Source the script RFA-fast-functions.R to import function definitions.
source('../../Scripts/RFA-fast-functions.R')

# Import genotype and phenotype data.
import_data('genotypes.txt', 'phenotypes.txt')
# Arguments:
#   Path to a csv file listing the genotypes (no header)
#   Path to a text file listing the phenotypes
# The following global variables are created:
#   genotypes : (numeric matrix) Genotype matrix
#   y : (numeric vector) Phenotype vector
#   n : (int) Number of sites
#   q_list : (int vector) Number of states in each site


# Robustness to missing genotypes -----------------------------------------

# Modified version of the function predict_from_subsample in ref_free.R.
# Lasso regression is performed using the package glmnet.
predict_from_subsample <- function(genotypes, y, model_ord, frac_list, CV_k, niter) {
  
  prediction <- matrix(NA_real_, length(frac_list), niter, dimnames = list(frac_list))
  
  A <- construct_phenotype_operator(genotypes, generate_site_combn(model_ord))
  
  for(i in seq_along(frac_list)) {
    
    cat('Prediction with sample size', frac_list[i], '\n')
    
    for(j in 1L:niter) {
      
      train_set <- sample(nrow(genotypes), nrow(genotypes) * frac_list[i]) # Sampling training/test set.
      
      # Cross-validation to determine the best-fit model for the training set.
      
      A_train <- A[train_set, -1L] # Excluding the intercept
      cv <- cv.glmnet(A_train, y[train_set], family = 'gaussian', nfolds = CV_k, alpha = 1)
      res <- glmnet(A_train, y[train_set], family = 'gaussian', alpha = 1, lambda = cv$lambda.min)
      e_inferred <- coef(res)
      
      # Evaluation on the test set.
      
      y_inferred <- as.vector(A %*% e_inferred)
      
      prediction[i, j] <-
        1 - sum((y[-train_set] - y_inferred[-train_set]) ^ 2L) / sum((y[-train_set] - mean(y[-train_set])) ^ 2L)
    }
  }
  
  prediction
}


# Sample size; fraction of all possible genotypes.
frac_list <- 1 / 2 ^ seq(9, 1, by = -1)

# Order of the model to infer.
model_ord <- 3L

# Number of genotype partitions for cross-validation.
CV_k <- 5L

# Number of trials.
niter <- 25L

res <- predict_from_subsample(genotypes, y, model_ord, frac_list, CV_k, niter)

write.table(signif(res, 3), 'Results-RFA.txt', col.names = FALSE)
