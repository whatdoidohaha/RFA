
# This script implements the functions for Fourier-analysis. The number of
# states must be identical across sites and be an exponential of 2. All
# genotypes must be sampled, and nonspecific epistasis is not modeled.
#
# Written in R version 4.3.1.
# Packages used and their version:

library(glmnet) # 4.1-7


# Import genotype and phenotype data.
import_data <- function(dir_genotypes, dir_phenotypes) {
  
  # dir_genotypes : character
  #   Path to a csv file listing the genotypes (no header).
  # dir_phenotypes : character
  #   Path to a text file listing the phenotypes.
  #
  # The following global variables are created:
  #
  # genotypes (int matrix) : Genotype matrix 
  # y (numeric vector) : Phenotype vector
  # n (int) : Number of sites
  # q (int) : Number of states
  #
  # States are renumbered as 1, 2, 3, ...
  
  genotypes <<- unname(as.matrix(read.csv(dir_genotypes, header = FALSE)))
  y <<- as.numeric(readLines(dir_phenotypes))
  
  if(!all(is.finite(genotypes)))
    stop('Genotype matrix contains missing entries.\n')
  
  if(!all(is.finite(y))) stop('Phenotype vector contains missing entries\n')
  
  if(nrow(genotypes) != length(y))
    stop('Genotype matrix and phenotype vector of different lengths.\n')
  
  n <<- ncol(genotypes) # Number of sites
  
  # Number of states in each site.
  q_list <<- apply(genotypes, 2L, function(x) length(unique(x)))
  
  if(length(unique(q_list)) > 1L)
    stop('Number of states different among sites.\n')
  
  # Recoding states if they are not 1, 2, 3, ... consecutively.
  
  # States in each site.
  states_list <- apply(genotypes, 2, function(x) sort(unique(x)), simplify = FALSE)
  
  # Checking for unused states.
  reducible <- vapply(states_list, function(x) length(x) != max(x), logical(1L))
  
  if(any(reducible)) {
    
    cat('States should be numbered 1, 2, 3, ... consecutively\n')
    cat('States renumbered for sites', which(reducible), '\n')
    genotypes <<- vapply(1:ncol(genotypes),
                         function(j) match(genotypes[, j], states_list[[j]]), genotypes[, 1L])
  }
}

# Generate all permutations of elements in a list of vectors, the right-most
# element changing fastest.
permutations <- function(vecs) {
  
  # If all vectors have only one element.
  if(all(sapply(vecs, length) == 1L)) return(matrix(unlist(vecs), nrow = 1L))
  
  if(length(vecs) == 1L) {
    
    matrix(vecs[[1L]], ncol = 1L)
    
  } else {
    
    sp <- permutations(vecs[-1L])
    cbind(rep(vecs[[1L]], each = nrow(sp)), do.call(rbind, rep(list(sp), length(vecs[[1L]]))))
  }
}

# Enumerate all genotypes in the canonical arrangement (the state in the right-
# most site changing fastest).
enumerate_genotypes <- function(n, q) {
  
  # n, q : int
  #   Number of sites (n) and states (q).
  
  permutations(rep(list(seq(q)), n))
}

# Considering state 1 as the wild-type state, compute the number of mutations
# in each genotype assuming that the genotypes are in the canonical arrangement.
identify_genotype_order <- function(n, q) {
  
  # n, q : int
  #   Number of sites (n) and states (q).
  
  O1 <- diag(q, nrow = q, ncol = q)
  O1[1L, 1L] <- 1
  
  O <- O1
  
  if(n > 1L) {
    
    for(i in 2L:n) {
      O <- kronecker(O1, O)
    }
  }
  
  round(diag(log(O, q)))
}

# Generate the epistasis operator. This is a matrix that, when multipled to the
# phenotype vector (in the canonical arragement), returns the Fourier coefficients.
construct_epistasis_operator <- function(d) {
  
  # d : int
  #   Dimension of the inverse Hadamard matrix.
  
  t(construct_phenotype_operator(d)) / d
}

# Generate the phenotype operator. This is a matrix that, when multipled to a
# vector of Fourier coefficients (in the canonical arragement), returns the phenotypes.
construct_phenotype_operator <- function(d) {
  
  # d : int
  #   Dimension of the desired Hadamard matrix.
  
  if(d == 1L) return(1)
  
  H <- construct_phenotype_operator(d / 2L)
  
  unname(cbind(rbind(H, H), rbind(H, -H)))
}

# Infer background-averaged effects from a sample of genotypes and use them to
# predict the phenotype of every genotype.
predict_from_subsample <- function(n, q, genotypes, y, model_ord, frac_list,
                                   CV_k, niter) {
  
  # n, q : int
  #   Number of sites (n) and states (q).
  # genotypes : numeric matrix
  #   Genotype matrix.
  # y : numeric vector
  #   Phenotype vector.
  # model_ord : int
  #   Model order.
  # frac_list : numeric vector
  #   Sample size (fraction of all possible genotypes).
  # CV_k : int
  #   Number of genotype partitions in cross-validaiton.
  # niter : int
  #   Number of times the analysis should be repeated.
  
  # To record the R-squared values.
  prediction <- matrix(NA_real_, length(frac_list), niter, dimnames = list(frac_list))
  
  ord <- identify_genotype_order(n, q)
  X <- construct_phenotype_operator(q ^ n)
  X <- X[, ord <= model_ord]
  
  for(i in seq_along(frac_list)) {
    
    cat('Prediction with sample size', frac_list[i], '\n')
    
    for(j in seq(niter)) {
      
      train_set <- sample(q ^ n, q ^ n * frac_list[i]) # Sampling the train set
      
      # Cross-validation to determine the best-fit model for the training set.
      
      # Phenotype operator for the train set; the intercept is removed because
      # glmnet introduces its own intercept.
      X_train <- X[train_set, -1L]
      
      # Lasso regression.
      cv <- cv.glmnet(X_train, y[train_set], family = 'gaussian', nfolds = CV_k,
                      alpha = 1)
      res <- glmnet(X_train, y[train_set], family = 'gaussian', alpha = 1,
                    lambda = cv$lambda.min)
      
      # Inferred Fourier coefficients.
      b_inferred <- coef(res)
      
      # Evaluation on the test set.
      
      y_inferred <- as.vector(X %*% b_inferred)
      prediction[i, j] <- 1 - sum((y[-train_set] - y_inferred[-train_set]) ^ 2L) / 
        sum((y[-train_set] - mean(y[-train_set])) ^ 2L)
    }
  }
  
  prediction
}

# Generate a dotplot with standard deviation or standard error.
dotplot_with_sd <- function(X, Y, plot_SEM = FALSE, ...) {
  
  # X, Y : numeric vector, matrix, or list
  #   If a matrix, rows correspond to data points and columns to replicate values.
  #   If a vector, Sd is not plotted.
  # plot_SEM : boolean
  #   If `TRUE`, plots standard error of the mean; otherwise plots standard deviation.
  # ... : optional additional parameters
  #   Passed to `plot` for managing graphic parameters.
  
  if(is.vector(X) & !is.list(X)) X <- vapply(X, as.list, list(1))
  if(is.vector(Y) & !is.list(Y)) Y <- vapply(Y, as.list, list(1))
  if(is.matrix(X)) X <- split(X, rep(1L:nrow(X), ncol(X)))
  if(is.matrix(Y)) Y <- split(Y, rep(1L:nrow(Y), ncol(Y)))
  
  X_mean <- vapply(X, mean, numeric(1L), na.rm = TRUE)
  Y_mean <- vapply(Y, mean, numeric(1L), na.rm = TRUE)
  
  if(plot_SEM) {
    
    X_range <- cbind(X_mean - vapply(X, function(x) sd(x, na.rm = TRUE) / sqrt(sum(is.finite(x))), 0),
                     X_mean + vapply(X, function(x) sd(x, na.rm = TRUE) / sqrt(sum(is.finite(x))), 0))
    
    Y_range <- cbind(Y_mean - vapply(Y, function(x) sd(x, na.rm = TRUE) / sqrt(sum(is.finite(x))), 0),
                     Y_mean + vapply(Y, function(x) sd(x, na.rm = TRUE) / sqrt(sum(is.finite(x))), 0))
    
  } else {
    
    X_range <- cbind(X_mean - vapply(X, sd, numeric(1L), na.rm = TRUE), X_mean + vapply(X, sd, numeric(1L), na.rm = TRUE))
    Y_range <- cbind(Y_mean - vapply(Y, sd, numeric(1L), na.rm = TRUE), Y_mean + vapply(Y, sd, numeric(1L), na.rm = TRUE)) 
  }
  
  plot(X_mean, Y_mean, ...)
  
  for(k in 1L:length(X)) {
    
    if(all(is.finite(Y_range[k, ]))) arrows(x0 = X_mean[k], y0 = Y_range[k, 1L], x1 = X_mean[k], y1 = Y_range[k, 2L], angle = 90, code = 3, length = 0.1)
    if(all(is.finite(X_range[k, ]))) arrows(x0 = X_range[k, 1L], y0 = Y_mean[k], x1 = X_range[k, 2L], y1 = Y_mean[k], angle = 90, code = 3, length = 0.1)
  }
}


