
# Robustness of Fourier analysis to missing genotypes.
#
# Written in R version 4.3.1.
# Requires the R package glmnet (4.1-7).


# Settings (recommended not to change in a run) ---------------------------

# Source the script FA-functions.R to import function definitions.
source('../../Scripts/FA-functions.R')

# Import genotype and phenotype data. The genotypes must be arranged in the
# canonical order (the state in the right-most site changing fastest). The
# number of states must be identical across sites.
import_data('genotypes.txt', 'phenotypes.txt')
# Arguments:
#   Path to a csv file listing the genotypes (no header)
#   Path to a text file listing the phenotypes
# The following global variables are created:
#   genotypes : (numeric matrix) Genotype matrix
#   y : (numeric vector) Phenotype vector
#   n : (int) Number of sites
#   q_list : (int vector) Number of states in each site


# Robustness to missing genotypes -----------------------------------------

# Sample size; fraction of all possible genotypes.
frac_list <- 1 / 2 ^ seq(9, 1, by = -1)

# Order of the model to infer.
model_ord <- 3L

# Number of genotype partitions for cross-validation.
CV_k <- 5L

# Number of trials.
niter <- 40L

res <- predict_from_subsample(n, unique(q_list), genotypes, y, model_ord, frac_list, CV_k, niter)

write.table(signif(res, 3), 'Results-FA.txt', col.names = FALSE)
