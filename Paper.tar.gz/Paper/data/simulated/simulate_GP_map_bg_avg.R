
# This script simulates a GP map using background-averaged formalism.

source('~/Desktop/GP2/scripts/bg_avg.R')
set.seed(10)

n <- 3L # Number of sites
s <- 20L # Number of states
var_spec <- c(0.7, 1, rep(0, n - 2)) # Variance spectrum (need not sum to 1)
spar_spec <- c(0, 0, rep(1, n - 2)) # 0 means no term is exactly zero.
noise_var <- 0 # Measurement variance

# Simulation
res <- simulate_GP_map(n, s, var_spec, spar_spec, noise_var)

write.csv(res$genotypes, '~/Desktop/GP/data/Simulated/genotypes.txt', row.names = FALSE)
writeLines(as.character(res$y), '~/Desktop/GP/data/Simulated/phenotypes.txt')




